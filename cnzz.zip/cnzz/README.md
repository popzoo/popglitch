# zoo
   <ul>
    <li>时光轴页面展示，采用canvas技术渲染气泡，结合jquery的动画效果！</li>
重磅推出新一代人工智能AI小思，包括对话机器人、知识图谱、语义理解、自然语言处理工具。知识图谱融合了两千五百多万的实体，拥有亿级别的实体属性关系，机器人采用了基于知识图谱的语义感知与理解，致力于最强认知大脑。自然语言处理工具包的功能有：中文分词、词性标注、命名实体识别、关键词提取、文本摘要、新词发现、情感分析等。</li>
  </ul>
    <table>
        <tr><td><a href="https://popzoo.github.io/zoo/" target="_blank"><img src="https://rawcdn.githack.com/popzoo/zoo/912024488fd12525db0917d8a3adcc58bd374783/img/timelineshow.jpg" width="100%"></a></td></tr>
   </table>
   <ul>
    <li>新增<a href="https://popzoo.github.io/zoo/" style=" color:red; text-decoration:none" target="_blank">时光轴</a>展示功能，大家可以从这里查看脚本的出生，成长的历程，而且还集成了AI人工小思机器人的聊天功能呦，常用的聊天弹幕，就是这个小家伙发出的，很智能，有木有！</li>
  </ul>
